from fastapi import FastAPI
from pyspark.sql import SparkSession
import mlflow

app = FastAPI()
spark = SparkSession.builder.getOrCreate()
model = mlflow.spark.load_model("runs:/<YOUR_RUN_ID>/model")  # Replace with your run ID

@app.post("/predict")
def predict(data: dict):
    # Convert input to Spark DataFrame
    input_df = spark.createDataFrame([data])
    
    # Get prediction
    prediction = model.transform(input_df).collect()[0]
    
    return {
        "prediction": int(prediction["prediction"]),
        "probability": float(prediction["probability"][1])  # Probability of class 1
    }